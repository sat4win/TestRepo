﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Program
    {
        private const int _numberofBreads = 10;

        static async Task Main(string[] args)
        {
            Console.WriteLine("Start Calculating Breads in India and Yemen!");

            Restaurant restaurant = new Restaurant();

            IEnumerable<int> breadFromIndia = await restaurant.GetBreadIndianWayAsync(_numberofBreads);
            IAsyncEnumerable<int> breadsFromYemen = restaurant.GetBreadYemeniWayAsync(_numberofBreads);

            foreach (var item in breadFromIndia)
            {
                Console.WriteLine($"{item}: Indian Bread Ready To serve");
            }

            await foreach (var item in breadsFromYemen)
            {
                Console.WriteLine($"{item}: Indian Bread Ready To serve");
            }
        }
    }

    public class Restaurant
    {
        public async Task<IEnumerable<int>> GetBreadIndianWayAsync(int numberOfBreads)
        {
            List<int> breadList = new List<int>();
            for (int i = 1; i <= numberOfBreads; i++)
            {
                Console.WriteLine($"Baking Indian Bread: {i}");
                await Task.Delay(1000);

                breadList.Add(i);
            }
            return breadList;
        }

        public async IAsyncEnumerable<int> GetBreadYemeniWayAsync(int numberOfBreads)
        {
            for (int i = 1; i <= numberOfBreads; i++)
            {
                Console.WriteLine($"Baking Yemeni Bread:{i}");
                await Task.Delay(1000);
                yield return i;
            }
        }
    }
}