using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using FluentValidation.AspNetCore;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Reflection;
using DbService.Models;
using Microsoft.EntityFrameworkCore;


namespace WebAPIProject
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        //this property will be used to read the applicaiton configuration setting for example read the data from appsetting.json file.
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers()
                .AddNewtonsoftJson()
                .AddFluentValidation(efv =>
                    {
                        efv.RegisterValidatorsFromAssemblyContaining<Startup>();
                        efv.RunDefaultMvcValidationAfterFluentValidationExecutes = false;
                    });
            services.AddSwaggerGen(opt =>
            {
                opt.CustomOperationIds(desc =>
                {
                    return desc.TryGetMethodInfo(out MethodInfo info) ? info.Name : null;
                });
            }).AddSwaggerGenNewtonsoftSupport();
            services.AddApiVersioning(versionoption =>
            {
                versionoption.DefaultApiVersion = new ApiVersion(1, 0);
                versionoption.AssumeDefaultVersionWhenUnspecified = true;
                versionoption.ReportApiVersions = true;
                versionoption.UseApiBehavior = false;
            });

            //Inject DB Context service
            services.AddDbContext<dbWebAPIDemoContext>(optionBuilder =>
            {
                optionBuilder.UseSqlServer(Configuration["ConnectionStrings:DefaultConnection"]);
            });
           
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
                    c.DisplayOperationId();
                });
            }
            else
            {
                app.UseExceptionHandler("/error");
            }
            
            app.UseRouting();

            app.UseAuthorization();            

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
