﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DbService.Models;
using FluentValidation;

namespace WebAPIProject.Validators
{
    public class EmployeeValidator : AbstractValidator<Employee>
    {
        public EmployeeValidator()
        {
            RuleFor(p => p.FirstName).NotEmpty();
        }
    }
}
