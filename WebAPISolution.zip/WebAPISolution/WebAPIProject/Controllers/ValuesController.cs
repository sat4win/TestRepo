﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        public static List<string> strings = new List<string>() {
        "Value0","Value1","Value2"
        };

        [HttpGet]
        public IEnumerable<string> Get()
        {
            return strings;
        }

        [HttpGet]
        [Route("{fname}")]
        public string Get(string fname)
        {
            return "Hello " + fname;
        }

        [HttpPost]
        public void Post([FromBody]string value)
        {
            strings.Add(value);
        }
        [HttpPut]
        [Route("{index}")]
        public void Put(int index, [FromBody]string value)
        {
            strings[index] = value;
        }
        
        [HttpDelete]
        [Route("{index}")]
        public void Delete(int index)
        {
            strings.RemoveAt(index);
        }
    }
}
