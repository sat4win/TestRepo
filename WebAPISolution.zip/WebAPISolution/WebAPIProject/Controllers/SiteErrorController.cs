﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteErrorController : ControllerBase
    {
        [HttpGet("/error")]
        public ActionResult SiteError()
        {
            var context = HttpContext.Features.Get<IExceptionHandlerFeature>();
            var stacktrace = context.Error.StackTrace;
            var errormsg = context.Error.Message;

            //Log the above error at somewhere;
            return Problem();
        }
    }
}
