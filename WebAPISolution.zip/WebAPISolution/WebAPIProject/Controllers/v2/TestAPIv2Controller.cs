﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIProject.Controllers.v2
{
    [ApiVersion("2.0")]
    [ApiController]
    public class TestAPIv2Controller : ControllerBase
    {
        [HttpGet]
        [Route("api/v2/TestAPIVersion")]
        public string Get()
        {
            return "Hello from version 2.0";
        }
    }
}
