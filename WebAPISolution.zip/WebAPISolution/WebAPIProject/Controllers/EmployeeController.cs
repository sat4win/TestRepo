﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DbService.Models;
using Microsoft.AspNetCore.JsonPatch;


namespace WebAPIProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private dbWebAPIDemoContext _dbContext;
        public EmployeeController(dbWebAPIDemoContext dc)
        {
            _dbContext = dc;
        }

        [HttpGet("test")]
        public ActionResult TestAPI([FromQuery] string msg)
        {
            return Ok("Hello " + msg);
        }

        [HttpGet("GetAllEmp")]
        public IEnumerable<Employee> GetAllEmployee()
        {
            //using (dbWebAPIDemoContext entity = new dbWebAPIDemoContext())
            //{
                return _dbContext.Employees.ToList();
            //}
        }

        [HttpGet]
        [Route("GetEmpById/{id:int}")]
        public ActionResult<string> GetEmpById(int id)
        {
            if (id == 0)
            {
                //return NotFound();
                throw new ArgumentException("Invalid Count");
            }

            if (id == -1)
            {
                return "InValid Input Paramteter";
            }
            //using (dbWebAPIDemoContext entity = new dbWebAPIDemoContext())
            //{
            //    return Ok(entity.Employees.FirstOrDefault(item => item.Id == id));
            //}
            return Ok(_dbContext.Employees.FirstOrDefault(item => item.Id == id));
        }
        [HttpGet]
        [Route("GetEmpByName/{firstName}")]
        public ActionResult<string> GetEmpByName(string firstName)
        {
            //using (dbWebAPIDemoContext entity = new dbWebAPIDemoContext())
            //{
            //    return Ok(entity.Employees.FirstOrDefault(item => item.FirstName == firstName));
            //}
            return Ok(_dbContext.Employees.FirstOrDefault(item => item.FirstName == firstName));
        }

        [HttpPost]
        [Route("SaveEmp")]
        public void SaveEmp([FromBody] Employee emp)
        {
            if (ModelState.IsValid)
            {
                //using (dbWebAPIDemoContext entity = new dbWebAPIDemoContext())
                //{
                //    entity.Employees.Add(emp);
                //    entity.SaveChanges();
                //}
                _dbContext.Employees.Add(emp);
                _dbContext.SaveChanges();
            }
        }

        [HttpPut("UpdateEmp")]        
        public ActionResult UpdateEmp([FromBody]Employee emp)
        {
            //using (dbWebAPIDemoContext entity = new dbWebAPIDemoContext())
            //{
            //    var item = entity.Employees.FirstOrDefault(e => e.Id == emp.Id);
            //    if (item != null)
            //    {
            //        item.FirstName = emp.FirstName;
            //        entity.Employees.Update(item);
            //        entity.SaveChanges();
            //        return Ok(item);
            //    }
            //    else
            //    {
            //        return NotFound();
            //    }                
            //}
           
            var item = _dbContext.Employees.FirstOrDefault(e => e.Id == emp.Id);
            if (item != null)
            {
                item.FirstName = emp.FirstName;
                _dbContext.Employees.Update(item);
                _dbContext.SaveChanges();
                return Ok(item);
            }
            else
            {
                return NotFound();
            }
           
        }        
        [HttpDelete("DeleteEmpById/{id}")]
        public ActionResult DeleteEmpById(int id)
        {
            try
            {
               
                var item = _dbContext.Employees.FirstOrDefault(item => item.Id == id);

                if (item == null)
                {
                    return NotFound("Record Not found");
                }
                else
                {
                    _dbContext.Employees.Remove(item);
                    _dbContext.SaveChanges();
                    return Ok("Record with id " + item.Id + " " + "deleted!");
                }
               
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPatch("UpdateEmpById/{Id}")]
        public async Task<ActionResult> UpdateEmpById(int Id, JsonPatchDocument<Employee> jEmp)
        {
           
            var item = _dbContext.Employees.FirstOrDefault(e => e.Id == Id);
            if (item != null)
            {
                jEmp.ApplyTo(item);
                _dbContext.Employees.Update(item);
                await _dbContext.SaveChangesAsync();

                return Ok();
            }
            else
            {
                return NotFound();
            }
           
        }

        }   

}
